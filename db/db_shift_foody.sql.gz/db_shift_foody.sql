-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2020 at 10:44 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_shift_foody`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookrrequest`
--

CREATE TABLE `bookrrequest` (
  `id` int(15) NOT NULL,
  `foodtruck_id` int(15) NOT NULL,
  `date` date NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `number_of_eaters` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `created_at`, `updated_at`, `deleted_at`, `name`, `img`) VALUES
(1, '2020-02-24 21:31:20', '2020-02-24 21:31:20', NULL, 'FRESH SEA FOODS', '/uploade/prefix_1582587080.png'),
(2, '2020-03-01 18:52:25', '2020-03-01 18:52:53', '2020-03-01 18:52:53', 'new cat', '/uploade/prefix_1583095965.png'),
(3, '2020-03-01 18:53:30', '2020-03-01 18:53:30', NULL, 'mew slider', '/uploade/prefix_1583096010.jpg'),
(4, '2020-03-01 18:54:11', '2020-03-01 18:54:11', NULL, 'new slider', '/uploade/prefix_1583096051.jpg'),
(5, '2020-03-01 18:55:06', '2020-03-01 18:55:06', NULL, 'new', '/uploade/prefix_1583096106.jpg'),
(6, '2020-03-01 18:56:06', '2020-03-01 18:56:06', NULL, 'new', '/uploade/prefix_1583096166.jpg'),
(7, '2020-03-01 18:56:35', '2020-03-01 18:56:35', NULL, 'new', '/uploade/prefix_1583096195.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int(15) NOT NULL,
  `message` text NOT NULL,
  `sender` varchar(20) NOT NULL DEFAULT 'user',
  `from` int(15) NOT NULL,
  `to` int(15) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `message`, `sender`, `from`, `to`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'hi', 'user', 1, 1, '2020-02-25 01:45:08', '2020-02-25 01:45:08', NULL),
(2, 'fgdfgdfgd', 'food-truck', 1, 1, '2020-02-29 14:06:26', '2020-02-29 14:06:26', NULL),
(3, 'fgdfgdfgd', 'food-truck', 1, 1, '2020-02-29 14:06:26', '2020-02-29 14:06:26', NULL),
(4, 'new test', 'user', 1, 1, '2020-03-01 19:08:24', '2020-03-01 19:08:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Riyadh', '2020-02-24 21:26:09', '2020-02-24 21:26:09', NULL),
(2, 'Makkah', '2020-02-24 21:26:34', '2020-02-24 21:26:34', NULL),
(3, 'Taif', '2020-02-24 21:27:02', '2020-02-24 21:27:02', NULL),
(4, 'Aldmam 123', '2020-03-01 18:51:44', '2020-03-01 18:51:59', '2020-03-01 18:51:59');

-- --------------------------------------------------------

--
-- Table structure for table `foodtruck`
--

CREATE TABLE `foodtruck` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fee` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `long` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `foodtruck`
--

INSERT INTO `foodtruck` (`id`, `created_at`, `updated_at`, `deleted_at`, `name`, `owner`, `fee`, `img`, `user_id`, `description`, `city_id`, `long`, `lat`, `status`) VALUES
(1, '2020-02-24 21:51:44', '2020-02-24 21:51:44', NULL, 'food truck', 'tag eldeen hassan', '6789', '/uploade/prefix_1582588304.png', 5, 'fdsasdfg', '1', '0', '0', 1),
(2, '2020-03-01 19:01:31', '2020-03-01 19:02:29', NULL, 'new food truck', 'nidal', '850', '/uploade/prefix_1583096491.jpg', 6, 'we have good food and test', '1', '-0.0013732910174155677', '0.0006866455097878088', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meal_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `meals`
--

CREATE TABLE `meals` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `foodtruck_id` int(11) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_special` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `meals`
--

INSERT INTO `meals` (`id`, `created_at`, `updated_at`, `deleted_at`, `name`, `price`, `img`, `category_id`, `foodtruck_id`, `description`, `is_special`) VALUES
(1, '2020-03-01 19:02:24', '2020-03-01 19:02:24', NULL, 'new m', '300', '/uploade/prefix_1583096544.jpg', 7, 2, 'dsasdas', 1),
(2, '2020-03-01 19:02:57', '2020-03-01 19:02:57', NULL, 'mew m 2', '600', '/uploade/prefix_1583096577.jpg', 1, 2, 'new desc', 1);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(15) NOT NULL,
  `foodtruck_id` int(15) NOT NULL,
  `review` varchar(255) NOT NULL,
  `rating` int(15) NOT NULL,
  `user_id` int(15) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `foodtruck_id`, `review`, `rating`, `user_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'good taste and service', 4, 2, '2020-02-25 00:07:17', NULL, NULL),
(2, 1, 'good taste and service', 2, 1, '2020-02-25 00:20:22', '2020-02-25 00:40:39', NULL),
(3, 1, 'good taste and service', 1, 4, '2020-02-25 00:07:17', '2020-02-25 00:40:50', NULL),
(4, 1, 'good taste and service', 5, 3, '2020-02-25 00:20:22', '2020-02-25 00:40:43', NULL),
(5, 1, 'good food ever', 4, 1, '2020-02-24 23:47:25', '2020-02-24 23:47:25', NULL),
(6, 2, 'good test', 3, 1, '2020-03-01 19:05:11', '2020-03-01 19:05:11', NULL),
(7, 2, 'hi  new review', 5, 1, '2020-03-01 19:05:49', '2020-03-01 19:05:49', NULL),
(8, 2, 'dddd', 1, 1, '2020-03-01 19:06:12', '2020-03-01 19:06:12', NULL),
(9, 2, 'ddddd', 5, 1, '2020-03-01 19:06:32', '2020-03-01 19:06:32', NULL),
(10, 2, 'ddddds', 5, 1, '2020-03-01 19:06:47', '2020-03-01 19:06:47', NULL),
(11, 2, 'gdfgdf', 1, 1, '2020-03-01 19:07:03', '2020-03-01 19:07:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `img`, `title`, `text`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '/uploade/prefix_1582586647.jpg', 'Enjoy Your Food at Foody', 'Enjoy Your Food at Foody', '2020-02-24 21:24:07', '2020-02-24 21:24:07', NULL),
(2, '/uploade/prefix_1582586681.jpg', 'Delecious Food', 'Delecious Food', '2020-02-24 21:24:41', '2020-02-24 21:24:41', NULL),
(3, '/uploade/prefix_1583096394.jpg', 'FRESH SEA FOODS', 'FRESH SEA FOODS', '2020-02-24 21:28:46', '2020-03-01 18:59:54', NULL),
(6, '/uploade/prefix_1583096341.jpg', 'new slider', 'slider test', '2020-03-01 18:59:01', '2020-03-01 18:59:01', NULL),
(7, '/uploade/prefix_1583096375.jpg', 'new test slider', 'new test desc', '2020-03-01 18:59:35', '2020-03-01 18:59:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `role`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'tag eldeen hassan ffff', 'taghassan54@gmail.com', 0, NULL, '$2y$10$UYWp.Ovv3dYIQyIEOY6fWu4aSK3UD7lWwQuYGrcF/aDPsXcvKZ1ZG', NULL, '2020-02-15 09:41:14', '2020-02-15 21:48:55'),
(2, 'aaa', 'taghassan55@gmail.com', 0, NULL, '$2y$10$7cPyilpbmyYLW5ZgFFCEN.PGw9/ieA7XLElVprbisPf9IuzYL3dlq', NULL, '2020-02-15 21:32:07', '2020-02-15 21:32:07'),
(3, 'tag eldeen hassan', 'taghassan@gmail.com', 0, NULL, '$2y$10$UYWp.Ovv3dYIQyIEOY6fWu4aSK3UD7lWwQuYGrcF/aDPsXcvKZ1ZG', NULL, '2020-02-15 21:52:24', '2020-02-15 21:52:24'),
(4, 'admin', 'admin@admin.com', 1, NULL, '$2y$10$kktnFy5UKUAsYTgrHuCgW.7iipZYztfi61nZK8bhRB.nSL/RT9u8C', NULL, '2020-02-24 21:21:43', '2020-02-24 21:21:43'),
(5, 'tag eldeen hassan', 'food1@admin.com', 2, NULL, '$2y$10$fTp5t.Q17y8bj2YfIYDyNelHqnWWgAz3RscLPf9YOXud/EFDmnJ4m', NULL, '2020-02-24 21:51:44', '2020-02-24 21:51:44'),
(6, 'nidal', 'nidal@admin.com', 2, NULL, '$2y$10$j7NzsrvT3039qNEWj1kKBO3XDhs2xucAatsb0.KKleaBkSpCcVTre', NULL, '2020-03-01 19:01:31', '2020-03-01 19:01:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookrrequest`
--
ALTER TABLE `bookrrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foodtruck`
--
ALTER TABLE `foodtruck`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meals`
--
ALTER TABLE `meals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookrrequest`
--
ALTER TABLE `bookrrequest`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `foodtruck`
--
ALTER TABLE `foodtruck`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `meals`
--
ALTER TABLE `meals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
